import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from sklearn.model_selection import ParameterSampler
from sklearn.metrics import accuracy_score

class LSTMModel(nn.Module):
    """
    A PyTorch-based LSTM model for sequence classification tasks.

    Args:
        input_size (int): The number of input features per time step.
        hidden_size (int): The number of features in the hidden state.
        num_layers (int): The number of recurrent layers in the LSTM.
        num_classes (int): The number of output classes.
        dropout (float): The dropout rate for regularization.
    """
    def __init__(self, input_size, hidden_size, num_layers, num_classes, dropout):
        super(LSTMModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, dropout=dropout if num_layers > 1 else 0)
        self.fc = nn.Linear(hidden_size, num_classes)
        self.dropout = nn.Dropout(dropout)
    
    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        
        out, _ = self.lstm(x, (h0, c0))
        out = self.dropout(out[:, -1, :])
        out = self.fc(out)
        return out

def create_sequences(data, labels, seq_length):
    """
    Create sequences from the input data and corresponding labels.

    Args:
        data (np.array): The input data array.
        labels (np.array): The corresponding labels array.
        seq_length (int): The length of each sequence.

    Returns:
        np.array: Array of sequences.
        np.array: Array of labels corresponding to the sequences.
    """
    sequences = []
    seq_labels = []
    for i in range(len(data) - seq_length + 1):
        seq = data[i:i+seq_length]
        label = labels[i+seq_length-1]
        sequences.append(seq)
        seq_labels.append(label)
    return np.array(sequences), np.array(seq_labels)

def custom_loss(output, target):
    """
    Compute the custom loss function which includes a penalty for 
    class imbalance.

    Args:
        output (torch.Tensor): The model predictions.
        target (torch.Tensor): The true labels.

    Returns:
        torch.Tensor: The computed loss value.
    """
    ce_loss = F.cross_entropy(output, target)
    _, predicted = torch.max(output.data, 1)
    unique, counts = torch.unique(predicted, return_counts=True)
    freq = dict(zip(unique.cpu().numpy(), counts.cpu().numpy()))

    penalty = 0
    for key, value in freq.items():
        if value > (0.6 * len(target)):  
            penalty += 0.3 * value 
    
    return ce_loss + penalty

def train_model(model, train_loader, criterion, optimizer, num_epochs):
    """
    Train the LSTM model using the provided training data loader.

    Args:
        model (LSTMModel): The LSTM model to train.
        train_loader (DataLoader): The data loader for training data.
        criterion (function): The loss function to optimize.
        optimizer (torch.optim.Optimizer): The optimizer for model parameters.
        num_epochs (int): The number of epochs to train the model.

    Returns:
        None
    """
    for epoch in range(num_epochs):
        model.train()
        total_loss = 0
        for sequences, labels in train_loader:
            sequences = sequences.view(sequences.size(0), sequences.size(1), -1)
            outputs = model(sequences)
            loss = criterion(outputs, labels)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

def hyperparameter_tuning(train_loader, val_loader, param_distribution, n_search, random_state):
    """
    Perform hyperparameter tuning for the LSTM model using grid search.

    Args:
        train_loader (DataLoader): The data loader for training data.
        val_loader (DataLoader): The data loader for validation data.
        param_distribution (dict): The grid of hyperparameters to search over.
        n_search (int): Number of searches.

    Returns:
        dict: The best hyperparameters found during tuning.
    """
    best_acc = 0.0
    best_params = None

    param_combinations = list(ParameterSampler(param_distribution, n_iter=n_search, random_state=random_state))

    for params in param_combinations:
        print(f"Testing parameters: {params}")
        
        model = LSTMModel(
            input_size=100,
            hidden_size=params['hidden_size'],
            num_layers=params['num_layers'],
            num_classes=3,
            dropout=params['dropout']
        )
                        
        optimizer = optim.Adam(model.parameters(), lr=params['lr'])
        train_model(model, train_loader, custom_loss, optimizer, params['num_epochs'])
        
        model.eval()
        y_pred = []
        y_true = []
        with torch.no_grad():
            for sequences, labels in val_loader:
                sequences = sequences.view(sequences.size(0), sequences.size(1), -1)
                outputs = model(sequences)
                _, predicted = torch.max(outputs.data, 1)
                y_pred.extend(predicted.cpu().numpy())
                y_true.extend(labels.cpu().numpy())

        acc = accuracy_score(y_true, y_pred)
        print(f"Validation Accuracy: {acc:.4f}")
        
        if acc > best_acc:
            best_acc = acc
            best_params = params
    
    print(f"Best Accuracy: {best_acc:.4f} with parameters: {best_params}")
    return best_params