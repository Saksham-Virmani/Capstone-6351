import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.mixture import GaussianMixture

def identify_regimes(data, mavg_diff_threshold=1, shift=20):
    """
    Identifies market regimes based on MACD and moving averages.

    Args:
        data (pd.DataFrame): DataFrame containing stock price and technical indicators.
        mavg_diff_threshold (int, optional): Threshold to classify a neutral regime. Defaults to 1.

    Returns:
        pd.DataFrame: DataFrame with an additional 'regime' column indicating the identified regime.
    """
    df = data.copy()
    regime_df = data.loc[:, ['close', 'SMA_short', 'SMA_long', 'MACD']]
    regime_df.drop_duplicates(inplace=True)
    
    def classify_regime(row):
        if abs(row['MACD']) < mavg_diff_threshold:
            return 1
        elif row['MACD'] > 0:
            return 2
        else:
            return 0

    df['regime'] = regime_df.apply(classify_regime, axis=1).shift(-shift)
    df.dropna(inplace=True)

    return df

def plot_regimes(tickers, df):
    """
    Plots stock prices with color-coded market regimes for multiple tickers in a single figure.

    Args:
        tickers (list): List of stock ticker symbols.
        df (dict): Dictionary with tickers as keys and corresponding DataFrames as values.

    Returns:
        None: Displays the plots.
    """
    num_tickers = len(tickers)
    fig, axes = plt.subplots(num_tickers, 1, figsize=(14, 7 * num_tickers), sharex=True)

    if num_tickers == 1:
        axes = [axes]  

    for ax, ticker in zip(axes, tickers):
        data = df[ticker]
        regime_colors = {2: 'green', 0: 'red', 1: 'blue'}
        
        for i in range(1, len(data)):
            ax.plot(data.index[i-1:i+1], data['close'].iloc[i-1:i+1], 
                    color=regime_colors[data['regime'].iloc[i]])

        ax.plot(data.index, data['SMA_short'], label='Short-Term MA', color='yellow', linestyle='--', alpha=0.4)
        ax.plot(data.index, data['SMA_long'], label='Long-Term MA', color='orange', linestyle='--', alpha=0.4)
        
        custom_lines = [
            plt.Line2D([0], [0], color='blue', lw=4),
            plt.Line2D([0], [0], color='green', lw=4),
            plt.Line2D([0], [0], color='red', lw=4)
        ]
        ax.legend(custom_lines, ['Stagnant (Blue)', 'Bull (Green)', 'Bear (Red)'], loc='upper left')

        ax.set_title(f'Regime {ticker}')
        ax.set_ylabel('Price')

    plt.xlabel('Date')
    plt.show()
