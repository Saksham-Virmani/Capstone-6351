import numpy as np
import pandas as pd
from pyts.image import GramianAngularField
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import matplotlib.pyplot as plt

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def gaf_preprocess(data, fit=True):
    """
    Apply Gramian Angular Field (GAF) transformation to the input data.

    Args:
        data (numpy.ndarray): Input data to transform.
        fit (bool): Whether to fit the transformation to the data.

    Returns:
        numpy.ndarray: Transformed data as GAF images.
    """
    gaf = GramianAngularField(method='summation')
    transformed = gaf.fit_transform(data)[:, np.newaxis, :, :] if fit else gaf.transform(data)[:, np.newaxis, :, :]
    return (transformed - transformed.min()) / (transformed.max() - transformed.min())

class CNNEncoder(nn.Module):
    """
    Convolutional Neural Network (CNN) Encoder for extracting latent features.

    Args:
        latent_dim (int): Dimensionality of the latent space.
    """
    def __init__(self, latent_dim, dropout_rate=0.3):
        super(CNNEncoder, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1)
        self.bn1 = nn.BatchNorm2d(32)
        self.bn2 = nn.BatchNorm2d(64)
        self.bn3 = nn.BatchNorm2d(128)
        self.dropout = nn.Dropout(dropout_rate)
        self.fc1 = nn.Linear(128, 1024)
        self.fc2 = nn.Linear(1024, 512)
        self.fc_mean = nn.Linear(512, latent_dim)
        self.fc_logvar = nn.Linear(512, latent_dim)

    def forward(self, x):
        """
        Forward pass through the encoder.

        Args:
            x (torch.Tensor): Input tensor.

        Returns:
            torch.Tensor: Mean of the latent space distribution.
            torch.Tensor: Log variance of the latent space distribution.
        """
        x = F.max_pool2d(F.relu(self.bn1(self.conv1(x))), (2, 2))
        x = F.max_pool2d(F.relu(self.bn2(self.conv2(x))), (2, 2))
        x = F.max_pool2d(F.relu(self.bn3(self.conv3(x))), (2, 2))
        x = self.dropout(x)
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        mean = self.fc_mean(x)
        logvar = self.fc_logvar(x)
        return mean, logvar

class CNNDecoder(nn.Module):
    """
    Convolutional Neural Network (CNN) Decoder for reconstructing data from latent features.

    Args:
        latent_dim (int): Dimensionality of the latent space.
    """
    def __init__(self, latent_dim=4, dropout_rate=0.3):
        super(CNNDecoder, self).__init__()
        self.fc_b = nn.Linear(latent_dim, 512)
        self.fc1 = nn.Linear(512, 1024)
        self.fc2 = nn.Linear(1024, 128 * 4 * 4)
        self.convt1 = nn.ConvTranspose2d(128, 64, 3)
        self.convt2 = nn.ConvTranspose2d(64, 32, 3)
        self.convt3 = nn.ConvTranspose2d(32, 1, 3)
        self.bn1 = nn.BatchNorm2d(64)
        self.bn2 = nn.BatchNorm2d(32)
        
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, z):
        """
        Forward pass through the decoder.

        Args:
            z (torch.Tensor): Latent vector.

        Returns:
            torch.Tensor: Reconstructed data.
        """
        z = F.relu(self.fc_b(z))
        z = F.relu(self.fc1(z))
        z = F.relu(self.fc2(z))
        z = z.view(z.size(0), 128, 4, 4)
        
        z = self.dropout(z)
        z = F.relu(self.bn1(self.convt1(z)))
        z = F.relu(self.bn2(self.convt2(z)))
        z = torch.sigmoid(self.convt3(z))
        return z

class CNNVAE(nn.Module):
    """
    Convolutional Neural Network (CNN) Variational Autoencoder (VAE).

    Args:
        latent_dim (int): Dimensionality of the latent space.
    """
    def __init__(self, latent_dim=4, dropout_rate=0.3):
        super(CNNVAE, self).__init__()
        self.encoder = CNNEncoder(latent_dim, dropout_rate)
        self.decoder = CNNDecoder(latent_dim, dropout_rate)

    def reparameterize(self, mean, logvar):
        """
        Reparameterization trick to sample from N(mean, var) using standard normal distribution.

        Args:
            mean (torch.Tensor): Mean of the latent space distribution.
            logvar (torch.Tensor): Log variance of the latent space distribution.

        Returns:
            torch.Tensor: Sampled latent vector.
        """
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mean + eps * std

    def forward(self, x):
        """
        Forward pass through the VAE.

        Args:
            x (torch.Tensor): Input tensor.

        Returns:
            torch.Tensor: Reconstructed data.
            torch.Tensor: Mean of the latent space distribution.
            torch.Tensor: Log variance of the latent space distribution.
        """
        mean, logvar = self.encoder(x)
        z = self.reparameterize(mean, logvar)
        recon_x = self.decoder(z)
        return recon_x, mean, logvar

def loss_function(recon_x, x, mean, logvar):
    """
    Compute the loss function for the VAE.

    Args:
        recon_x (torch.Tensor): Reconstructed data.
        x (torch.Tensor): Original data.
        mean (torch.Tensor): Mean of the latent space distribution.
        logvar (torch.Tensor): Log variance of the latent space distribution.

    Returns:
        torch.Tensor: Total loss (MSE + KLD).
    """
    MSE = nn.functional.mse_loss(recon_x, x, reduction='sum')
    KLD = -0.5 * torch.sum(1 + logvar - mean.pow(2) - logvar.exp())
    return MSE + KLD

def train_cvae(model, train_loader, optimizer, epochs=10):
    """
    Train the CNN VAE model.

    Args:
        model (CNNVAE): The VAE model to be trained.
        train_loader (DataLoader): DataLoader for training data.
        optimizer (torch.optim.Optimizer): Optimizer for model training.
        epochs (int): Number of epochs to train the model.
    """
    model.train()
    for epoch in range(epochs):
        train_loss = 0
        for batch_idx, data in enumerate(train_loader):
            data = data[0].to(device)
            optimizer.zero_grad()
            recon_batch, mean, logvar = model(data)
            loss = loss_function(recon_batch, data, mean, logvar)
            loss.backward()
            train_loss += loss.item()
            optimizer.step()

def generate_synthetic_data(model, n_samples):
    """
    Generate synthetic data using the trained VAE model.

    Args:
        model (CNNVAE): The trained VAE model.
        n_samples (int): Number of synthetic samples to generate.

    Returns:
        numpy.ndarray: Generated synthetic data.
    """
    model.eval()
    with torch.no_grad():
        z = torch.randn(n_samples, model.module.encoder.fc_mean.out_features).to(device)
        synthetic_data = model.module.decoder(z).cpu().numpy()
    return synthetic_data

def create_sliding_windows(data, timestamps, window_size):
    """
    Create sliding windows of data grouped by unique timestamps.

    Args:
        data (numpy.ndarray): Input data to be windowed.
        timestamps (numpy.ndarray): Array of timestamps corresponding to data points.
        window_size (int): Size of each sliding window.

    Returns:
        list: List of NumPy arrays, each representing a sliding window.
    """
    unique_timestamps = np.unique(timestamps)
    grouped_data = [data[timestamps == timestamp] for timestamp in unique_timestamps]
    sliding_windows = [np.vstack(grouped_data[i:i + window_size]) 
                       for i in range(len(grouped_data) - window_size + 1)]
    return sliding_windows

def get_window_labels(y_train, timestamps, window_size):
    """
    Extract labels for each sliding window, accounting for multiple data points per timestamp.

    Args:
        y_train (pandas.Series): Labels corresponding to the training data.
        timestamps (numpy.ndarray): Array of timestamps corresponding to data points.
        window_size (int): Size of each sliding window.

    Returns:
        numpy.ndarray: Array of labels for each window.
    """
    unique_timestamps = np.unique(timestamps)
    grouped_labels = [y_train[timestamps == timestamp].iloc[0] for timestamp in unique_timestamps]
    return np.array([grouped_labels[i + window_size - 1] for i in range(len(grouped_labels) - window_size + 1)])

def compute_validation_loss(model, validation_loader):
    """
    Compute the validation loss for the VAE model.

    Args:
        model (CNNVAE): The VAE model.
        validation_loader (DataLoader): DataLoader for validation data.

    Returns:
        float: Average validation loss.
    """
    model.eval()
    val_loss = 0
    with torch.no_grad():
        for data in validation_loader:
            data = data[0].to(device)
            recon_batch, mean, logvar = model(data)
            val_loss += loss_function(recon_batch, data, mean, logvar).item()
    return val_loss / len(validation_loader.dataset)

def plot_synthetic_vs_original(gaf_images_dict, synthetic_data_dict, assets, num_examples=5, num_samples=3):
    """
    Plot original GAF images against corresponding synthetic images for multiple assets in a single figure with subplots.

    Args:
        gaf_images_dict (dict): Dictionary of original GAF images arrays with asset symbols as keys.
        synthetic_data_dict (dict): Dictionary of synthetic images arrays with asset symbols as keys.
        assets (list): List of asset symbols to plot.
        num_examples (int): Number of random examples to plot per asset.
        num_samples (int): Number of synthetic samples generated per example.
    """
    num_assets = len(assets)
    fig, axes = plt.subplots(num_assets * num_examples, num_samples + 1, figsize=(15, num_assets * num_examples * 3))
    
    for asset_idx, asset in enumerate(assets):
        gaf_images = gaf_images_dict[asset]["gaf_images_train"]
        synthetic_data = synthetic_data_dict[asset]
        indices = np.random.choice(len(gaf_images), num_examples, replace=False)

        for i, idx in enumerate(indices):
            row = asset_idx * num_examples + i
            axes[row, 0].imshow(gaf_images[idx, 0], cmap='gray')
            axes[row, 0].set_title(f"{asset} Original GAF Image {idx+1}")
            axes[row, 0].axis('off')
            
            for j in range(num_samples):
                axes[row, j + 1].imshow(synthetic_data[idx * num_samples + j, 0], cmap='gray')
                axes[row, j + 1].set_title(f"{asset} Synthetic {j+1}")
                axes[row, j + 1].axis('off')
    
    plt.tight_layout()
    plt.show()