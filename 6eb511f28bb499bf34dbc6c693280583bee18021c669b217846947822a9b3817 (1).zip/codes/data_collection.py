import os
import time
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import requests
import numpy as np
import pandas as pd
import yfinance as yf
from tqdm import tqdm
from datasets import Dataset
from transformers import BertTokenizer, BertForSequenceClassification
import torch
from statsmodels.stats.outliers_influence import variance_inflation_factor
import warnings

warnings.filterwarnings('ignore')

device = 0 if torch.cuda.is_available() else -1

def fetch_news(tickers, start_date, end_date, top_n=3, output_dir="data"):
    """
    Fetches the top N GDELT news articles for specified stock tickers between given dates and saves the data in CSV files.

    Args:
        tickers (list): List of stock ticker symbols.
        start_date (str): Start date in 'YYYY-MM-DD' format.
        end_date (str): End date in 'YYYY-MM-DD' format.
        top_n (int, optional): Number of top articles to fetch per day. Defaults to 3.
        output_dir (str, optional): Directory to save the CSV files. Defaults to 'data'.
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for ticker in tickers:
        csv_path = os.path.join(output_dir, f"{ticker}.csv")
        
        if os.path.exists(csv_path):
            print(f"CSV for {ticker} already exists. Skipping data retrieval.")
            continue
        
        print(f"Fetching data for {ticker}...")
        start_time = time.time()
        
        current = datetime.strptime(start_date, '%Y-%m-%d')
        end = datetime.strptime(end_date, '%Y-%m-%d')
        all_data = []

        total_days = (end - current).days + 1

        with tqdm(total=total_days, desc=f"Fetching {ticker}") as pbar:
            while current <= end:
                date_from = current.strftime('%Y%m%d%H%M%S')
                date_to = (current + timedelta(days=1)).strftime('%Y%m%d%H%M%S')
    
                url = f'https://api.gdeltproject.org/api/v2/doc/doc?query={ticker}&mode=artlist&startdatetime={date_from}&enddatetime={date_to}&maxrecords={top_n}&format=json'
                response = requests.get(url)
    
                if response.status_code == 200:
                    try:
                        data = response.json()
                        if 'articles' in data:
                            df = pd.DataFrame(data['articles'])
                            all_data.append(df)
                    except ValueError as e:
                        print(f"JSON decoding failed for date {current.strftime('%Y-%m-%d')}: {e}")
                else:
                    print(f"Request failed for date {current.strftime('%Y-%m-%d')} with status code {response.status_code}")

                current += timedelta(days=1)
                pbar.update(1)

        if all_data:
            final_df = pd.concat(all_data, ignore_index=True)
            final_df.to_csv(csv_path, index=False)
            elapsed_time = (time.time() - start_time) / 60  
            print(f"Data for {ticker} stored in {csv_path}. Retrieval took {elapsed_time:.2f} minutes.")
        else:
            elapsed_time = (time.time() - start_time) / 60  
            print(f"No data retrieved for {ticker}. Process took {elapsed_time:.2f} minutes.")


def process_news(df):
    """
    Processes the news data by extracting and cleaning the relevant text and date information.

    Args:
        df (pd.DataFrame): DataFrame containing news articles.

    Returns:
        pd.DataFrame: DataFrame containing titles and corresponding dates.
    """
    text = df[['title']]
    df['seendate'] = pd.to_datetime(df['seendate'], format='%Y%m%dT%H%M%SZ').dt.date
    text['date'] = df['seendate']
    text.dropna(inplace=True)
    return text


def get_sentiment_scores_batch(texts, model, tokenizer, max_length=512, device='cuda'):
    """
    Computes sentiment scores for a batch of texts using a pre-trained model.

    Args:
        texts (list): List of texts to analyze.
        model (transformers.BertForSequenceClassification): Pre-trained BERT model for sentiment analysis.
        tokenizer (transformers.BertTokenizer): Tokenizer for the BERT model.
        max_length (int, optional): Maximum length of the tokenized input. Defaults to 512.
        device (str, optional): Device to run the model on ('cuda' or 'cpu'). Defaults to 'cuda'.

    Returns:
        np.ndarray: Array of sentiment scores.
    """
    inputs = tokenizer(texts, return_tensors='pt', truncation=True, padding=True, max_length=max_length).to(device)
    with torch.no_grad():
        outputs = model(**inputs)
        scores = torch.nn.functional.softmax(outputs.logits, dim=-1)
        sentiment_scores = scores[:, 1] - scores[:, 0]
        
    sentiment_scores = sentiment_scores.cpu().numpy()
    
    mean = np.mean(sentiment_scores)
    sentiment_scores -= mean
    min_score = np.min(sentiment_scores)
    max_score = np.max(sentiment_scores)
    
    if max_score > min_score:
        sentiment_scores = 2 * (sentiment_scores - min_score) / (max_score - min_score) - 1
    
    return sentiment_scores


def aggregate_sentiment(df, batch_size=32, device='cuda'):
    """
    Aggregates sentiment scores for news articles on a daily basis.

    Args:
        df (pd.DataFrame): DataFrame containing news articles and their dates.
        batch_size (int, optional): Number of texts to process in each batch. Defaults to 32.
        device (str, optional): Device to run the model on ('cuda' or 'cpu'). Defaults to 'cuda'.

    Returns:
        pd.DataFrame: DataFrame with daily aggregated sentiment scores.
    """
    tokenizer = BertTokenizer.from_pretrained('yiyanghkust/finbert-tone')
    model = BertForSequenceClassification.from_pretrained('yiyanghkust/finbert-tone').to(device)
    model.eval()

    def get_combined_sentiment_for_date(date_df):
        titles = date_df['title'].tolist()
        all_scores = []
        for i in range(0, len(titles), batch_size):
            batch_texts = titles[i:i + batch_size]
            batch_scores = get_sentiment_scores_batch(batch_texts, model, tokenizer, device=device)
            all_scores.extend(batch_scores)
        
        sentiment_score = sum(all_scores) / len(all_scores)
        return pd.Series({'sentiment_score': sentiment_score})
    
    result = df.groupby('date').apply(get_combined_sentiment_for_date)
    result.index.name = None
    
    return result[['sentiment_score']]
     
            
def fetch_price(ticker, date_from, date_to):
    """
    Fetches daily stock price data (open, high, low, close, volume) for a given ticker between specified dates.

    Args:
        ticker (str): Stock ticker symbol.
        date_from (str): Start date in 'YYYY-MM-DD' format.
        date_to (str): End date in 'YYYY-MM-DD' format.

    Returns:
        pd.DataFrame: DataFrame with price data indexed by date.
    """
    df = yf.download(ticker, start=date_from, end=date_to)
    df = df[['Open', 'High', 'Low', 'Close', 'Volume']]
    df.columns = ['open', 'high', 'low', 'close', 'volume']
    return df


def technical_indicators(price_data, window_short=20, window_long=50):
    """
    Calculates various technical indicators (e.g., moving averages, RSI, MACD) for stock price data.

    Args:
        price_data (pd.DataFrame): DataFrame containing stock price data.
        window_short (int, optional): Window size for short-term indicators. Defaults to 20.
        window_long (int, optional): Window size for long-term indicators. Defaults to 50.

    Returns:
        pd.DataFrame: DataFrame containing calculated technical indicators.
    """
    df = pd.DataFrame(index=price_data.index)

    df['returns'] = price_data['close'].pct_change()
    df['returns_10'] = df['returns'].rolling(10).apply(lambda x: np.prod(1 + x / 100) - 1)
    df['returns_25'] = df['returns'].rolling(25).apply(lambda x: np.prod(1 + x / 100) - 1)
    df['returns_50'] = df['returns'].rolling(50).apply(lambda x: np.prod(1 + x / 100) - 1)
    
    df['SMA_short'] = price_data['close'].rolling(window=window_short).mean()
    df['SMA_long'] = price_data['close'].rolling(window=window_long).mean()
    df['EMA_short'] = price_data['close'].ewm(span=window_short, adjust=False).mean()
    df['EMA_long'] = price_data['close'].ewm(span=window_long, adjust=False).mean()

    df['std_dev'] = price_data['close'].rolling(window=window_short).std()
    df['upper_band'] = df['SMA_short'] + (df['std_dev'] * 2)
    df['lower_band'] = df['SMA_short'] - (df['std_dev'] * 2)

    delta = price_data['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=window_short).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=window_short).mean()
    rs = gain / loss
    df['RSI'] = 100 - (100 / (1 + rs))

    df['MACD'] = df['EMA_short'] - df['EMA_long']
    df['MACD_signal'] = df['MACD'].ewm(span=9, adjust=False).mean()
    df['MACD_histogram'] = df['MACD'] - df['MACD_signal']

    tr1 = price_data['high'] - price_data['low']
    tr2 = abs(price_data['high'] - price_data['close'].shift())
    tr3 = abs(price_data['low'] - price_data['close'].shift())
    df['ATR'] = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1).rolling(window=window_short).mean()

    return df


def wrangle_data(*dfs):
    """
    Merges multiple DataFrames on their indices and drops rows with missing values.

    Args:
        *dfs: Variable length argument list of DataFrames to be merged.

    Returns:
        pd.DataFrame: Merged DataFrame with no missing values.
    """
    df = dfs[0]
    for i in dfs[1:]:
        df = pd.merge(df, i, how='left', left_index=True, right_index=True)
    df.dropna(inplace=True)
    
    return df


def remove_multicollinear_features(df, threshold=5.0):
    """
    Removes features from a DataFrame that have high multicollinearity based on Variance Inflation Factor (VIF).

    Args:
        df (pd.DataFrame): DataFrame with features to check for multicollinearity.
        threshold (float, optional): VIF threshold above which a feature is considered multicollinear. Defaults to 5.0.

    Returns:
        pd.DataFrame: DataFrame with features that have VIF below the specified threshold.
    """
    features = df.copy()
    
    vif_data = pd.DataFrame()
    vif_data['feature'] = features.columns
    vif_data['VIF'] = [variance_inflation_factor(features.values, i) for i in range(len(features.columns))]
    
    while vif_data['VIF'].max() > threshold:
        max_vif_feature = vif_data.loc[vif_data['VIF'].idxmax(), 'feature']
        print(f"Dropping {max_vif_feature} with VIF: {vif_data['VIF'].max()}")
        features = features.drop(columns=[max_vif_feature])
        
        vif_data = pd.DataFrame()
        vif_data['feature'] = features.columns
        vif_data['VIF'] = [variance_inflation_factor(features.values, i) for i in range(len(features.columns))]

    return df[features.columns.tolist()]

def plot_sentiment(tickers, df):
    """
    Plots the stock's closing prices with color coding based on sentiment scores.

    Args:
        tickers (list): List of stock ticker symbols.
        df (dict): Dictionary with tickers as keys and corresponding DataFrames as values.

    Returns:
        None: Displays the plot.
    """
    num_tickers = len(tickers)
    fig, axes = plt.subplots(num_tickers, 1, figsize=(14, 7 * num_tickers), sharex=True)

    if num_tickers == 1:
        axes = [axes]

    for ax, ticker in zip(axes, tickers):
        data = df[ticker]

        for i in range(1, len(data)):
            if data['sentiment_score'].iloc[i] > 0.2:
                color = 'green'
            elif data['sentiment_score'].iloc[i] < -0.2:
                color = 'red'
            else:
                color = 'blue'
            
            ax.plot(data.index[i-1:i+1], data['close'].iloc[i-1:i+1], color=color)
    
    
        custom_lines = [
            plt.Line2D([0], [0], color='green', lw=4),
            plt.Line2D([0], [0], color='red', lw=4),
            plt.Line2D([0], [0], color='blue', lw=4)
        ]
        ax.legend(custom_lines, ['Positive Sentiment', 'Negative Sentiment', 'Neutral Sentiment'], loc='upper left')

        ax.set_title(f'Sentiments {ticker}')
        ax.set_ylabel('Price')
        
    plt.xlabel('Date')
    plt.show()

